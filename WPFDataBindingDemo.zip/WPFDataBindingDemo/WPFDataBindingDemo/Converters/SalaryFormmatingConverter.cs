﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace WPFDataBindingDemo
{
    public class SalaryFormmatingConverter : IValueConverter
    {

        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double dollars = 0;

            if (value == null)
            {
                throw new NullReferenceException("value can not be null");
            }
            double.TryParse(value.ToString(), out dollars);
            return $"Total={dollars}$";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }

        #endregion
    }

}
