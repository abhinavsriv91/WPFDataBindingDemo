﻿using System.Collections.ObjectModel;

namespace WPFDataBindingDemo
{
    public class Persons : ObservableCollection<Person>
    {
        public Persons()
        {
            Add(new Person()
            {
                Name = "Sachin",
                Age = 20,
                Interest = "Cricket",
                Job = "programmer",
                Salary = 300
            });

            Add(new Person()
            {
                Name = "employee2",
                Age = 21,
                Interest = "CS",
                Job = "programmer",
                Salary = 200
            });

            Add(new Person()
            {
                Name = "employee3",
                Age = 21,
                Interest = "FIFA",
                Job = "programmer",
                Salary = 300
            });
        }
    }
}
