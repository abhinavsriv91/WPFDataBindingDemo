﻿using System.ComponentModel;

namespace WPFDataBindingDemo
{
    public class Person : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        #region Member Variables

        string name;
        int age;
        string job;
        int salary;
        string interest;
        bool visiprop;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>name</value>
        public string Name
        {
            get { return name; }
            set
            {
                if (value != name)
                {
                    name = value;
                    OnPropertyChanged("Name");
                }
            }
        }

        /// <summary>
        /// Gets or sets the age.
        /// </summary>
        /// <value>age</value>
        public int Age
        {
            get { return age; }
            set
            {
                if (value != age)
                {
                    age = value;
                    OnPropertyChanged("Age");
                }
            }
        }

        /// <summary>
        /// Gets or sets the job.
        /// </summary>
        /// <value>The job.</value>
        public string Job
        {
            get { return job; }
            set
            {
                if (value != job)
                {
                    job = value;
                    OnPropertyChanged("Job");
                }
            }
        }

        /// <summary>
        /// Gets or sets the salary.
        /// </summary>
        /// <value>The salary.</value>
        public int Salary
        {
            get { return salary; }
            set
            {
                if (value != salary)
                {
                    salary = value;
                    OnPropertyChanged("Salary");
                }
            }
        }

        /// <summary>
        /// Gets or sets the interest.
        /// </summary>
        /// <value>The interest.</value>
        public string Interest
        {
            get { return interest; }
            set
            {
                if (value != interest)
                {
                    interest = value;
                    OnPropertyChanged("Interest");
                }

            }
        }

        public bool Visiprop
        {
            get { return visiprop; }
            set
            {
                if (value != visiprop)
                {
                    visiprop = value;
                    OnPropertyChanged("Visiprop");
                }
            }
        }

        #endregion

        #region PropertyChangedEvents

        /// <summary>
        /// Fire the property changed event
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

        #region Constructor

        public Person()
        {
            Name = "Default";
            Job = "None";
            Age = 20;
            Interest = "None";
            Salary = 500;
        }

        #endregion

    }

}
