﻿using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WPFDataBindingDemo
{
    public class AgeValidationRule : ValidationRule
    {

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var age = 0;
            if (value != null)
            {
                int.TryParse(value.ToString(), out age);
            }
            if (age < 0 || age > 100)
            {
                return new ValidationResult(false, "!");
            }

            return new ValidationResult(true, null);
        }
    }
}
