﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace WPFDataBindingDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Person person;
        Persons persons;

        #region Constructor

        public MainWindow()
        {
            person = new Person();
            persons = new Persons();

            InitializeComponent();

            person.Name = "Abhinav";
            person.Job = "SE";
            person.Interest = "Politics";
            person.Salary = 100;
            person.Age = 26;
            SetBindings();

            // myMedia.Volume = 100;
            // myMedia.Play();
        }

        #endregion

        #region Private Methods

        private void SetBindings()
        {
            // Set Binding for Name TextBox
            Binding twoWayBinding = new Binding();
            twoWayBinding.Mode = BindingMode.TwoWay;
            twoWayBinding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
            twoWayBinding.Source = person;
            twoWayBinding.Path = new PropertyPath("Name");
            BindingOperations.SetBinding(txtBoxPersonName, TextBox.TextProperty, twoWayBinding);

            // Set Binding for Job TextBox
            Binding oneWayToSourceBinding = new Binding();
            oneWayToSourceBinding.Mode = BindingMode.OneWayToSource;
            oneWayToSourceBinding.UpdateSourceTrigger = UpdateSourceTrigger.LostFocus;
            oneWayToSourceBinding.Source = person;
            oneWayToSourceBinding.Path = new PropertyPath("Job");
            BindingOperations.SetBinding(txtBoxPersonJob, TextBox.TextProperty, oneWayToSourceBinding);

            // Set Binding for Age TextBox
            Binding twoWayBinding2 = new Binding();
            twoWayBinding2.UpdateSourceTrigger = UpdateSourceTrigger.LostFocus;
            twoWayBinding2.Source = person;
            twoWayBinding2.Mode = BindingMode.TwoWay;
            twoWayBinding2.ValidationRules.Add(new AgeValidationRule());
            twoWayBinding2.Path = new PropertyPath("Age");
            BindingOperations.SetBinding(txtBoxPersonAge, TextBox.TextProperty, twoWayBinding2);

            // Set Binding for Salary TextBox 
            Binding twoWayBinding3 = new Binding();
            twoWayBinding3.Source = person;
            twoWayBinding3.Mode = BindingMode.TwoWay;
            twoWayBinding3.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
            twoWayBinding3.Path = new PropertyPath("Salary");
            BindingOperations.SetBinding(txtBoxPersonSalary, TextBox.TextProperty, twoWayBinding3);

            // Set Binding for  Interest TextBox
            Binding oneWayBinding2 = new Binding();
            oneWayBinding2.Source = person;
            oneWayBinding2.Mode = BindingMode.OneWay;
            oneWayBinding2.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
            oneWayBinding2.Path = new PropertyPath("Interest");
            BindingOperations.SetBinding(txtBoxPersonInterest, TextBox.TextProperty, oneWayBinding2);

            // Set Binding for Name Label
            Binding nameBinding = new Binding();
            nameBinding.Source = person;
            nameBinding.Path = new PropertyPath("Name");
            BindingOperations.SetBinding(lblPersonName, Label.ContentProperty, nameBinding);

            // Set Binding for Job Label
            Binding jobBinding = new Binding();
            jobBinding.Source = person;
            jobBinding.Path = new PropertyPath("Job");
            BindingOperations.SetBinding(lblPersonJob, Label.ContentProperty, jobBinding);

            // Set Binding for Age Label;
            Binding ageBinding = new Binding();
            ageBinding.Source = person;
            ageBinding.Path = new PropertyPath("Age");
            BindingOperations.SetBinding(lblPersonAge, Label.ContentProperty, ageBinding);

            // Set Binding for Salary Label
            Binding salaryBinding = new Binding();
            salaryBinding.Source = person;
            salaryBinding.Converter = new SalaryFormmatingConverter();
            salaryBinding.Path = new PropertyPath("Salary");
            BindingOperations.SetBinding(lblPersonSalary, Label.ContentProperty, salaryBinding);

            // Set Binding for  Label Interest
            Binding interestBinding = new Binding();
            interestBinding.Source = person;
            interestBinding.Path = new PropertyPath("Interest");
            BindingOperations.SetBinding(lblPersonInterest, Label.ContentProperty, interestBinding);

            // Set itemsource of listBox
            //lbPerson.ItemsSource = persons;
        }


        //private void btnClick_Click(object sender, RoutedEventArgs e)
        //{
        //    MessageBox.Show("Hi I am Button : " + (sender as Button).Content.ToString());
        //}

        private void changeResourceButton_Click(object sender, RoutedEventArgs e)
        {
            SolidColorBrush myBrush = Brushes.Red;

            Application.Current.Resources["brushResource"] = myBrush;
        }


        #region Bubbling
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            txt1.Text = "Button is Clicked";
        }

        private void StackPanel_Click(object sender, RoutedEventArgs e)
        {
            txt2.Text = "Click event is bubbled to Stack Panel";
        }

        private void Window_Click(object sender, RoutedEventArgs e)
        {
            txt3.Text = "Click event is bubbled to Window";
        }

        private void Grid_Click(object sender, RoutedEventArgs e)
        {
            txt4.Text = "Click event is bubbled to Grid";
            e.Handled = true;
        }

        #endregion

        #region Tunneling

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show(" Captured in Window_PreviewKeyDown");
        }

        private void StackPanel_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("Captured in StackPanel_PreviewKeyDown");
        }

        private void Grid1_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("Captured in Grid1_PreviewKeyDown");
        }

        private void Grid1_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("Captured in Grid1_KeyDown");
        }

        private void StackPanel_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("Captured in StackPanel_KeyDown");
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("Captured in Window_KeyDown");
        }

        #endregion

        #region Media

        //private void btnPlay_Click(object sender, RoutedEventArgs e)
        //{
        //    myMedia.Play();
        //}

        //private void btnPause_Click(object sender, RoutedEventArgs e)
        //{
        //    myMedia.Pause();
        //}

        //private void btnMute_Click(object sender, RoutedEventArgs e)
        //{
        //    if (myMedia.Volume != 0)
        //    {
        //        myMedia.Volume = 0;
        //        btnMute.Content = "Listen";
        //    }
        //    else
        //    {
        //        myMedia.Volume = 100;
        //        btnMute.Content = "Mute";
        //    }
        //}

        //private void btnTextToSpeech_Click(object sender, RoutedEventArgs e)
        //{
        //    if (!string.IsNullOrWhiteSpace(txtBox.Text))
        //    {
        //        SpeechSynthesizer speechSynthesizer = new SpeechSynthesizer();
        //        speechSynthesizer.Speak(txtBox.Text);
        //    }
        //    else
        //    {
        //        MessageBox.Show("Write some thing in the textbox!");
        //    }
        //}

        #endregion

        #endregion
    }
}
